export interface Product {
  slug: string;
  name: string;
  price: number;
  meta: string;
  stock: string;
  stockType: 'live' | 'soon';
  badge?: 'dropped' | 'soon';
  tag: string;
  description: string;
  details: string[];
  available: boolean;
  variant: 'tee' | 'hat' | 'bone';
}

export const products: Product[] = [
  {
    slug: 'drop-001-tee',
    name: 'Drop 001 Tee',
    price: 58,
    meta: 'Faded Grey · Heavyweight Cotton',
    stock: '17 of 24 remaining',
    stockType: 'live',
    badge: 'dropped',
    tag: '01',
    description:
      'Our first run tee — 240gsm cotton, garment-dyed in small batches for a lived-in fade from day one. Grid mark on chest.',
    details: [
      '240gsm heavyweight cotton',
      'Garment-dyed in Texas',
      'Double-needle stitching',
      'Relaxed fit — true to size',
    ],
    available: true,
    variant: 'tee',
  },
  {
    slug: 'washed-dad-hat',
    name: 'Washed Dad Hat',
    price: 38,
    meta: 'Walnut · 6-Panel Cotton',
    stock: '9 of 24 remaining',
    stockType: 'live',
    tag: '02',
    description:
      'Six-panel cotton cap, washed for softness. Embroidered wordmark. The kind of hat you forget you\'re wearing.',
    details: [
      '6-panel unstructured cotton',
      'Adjustable brass buckle',
      'Embroidered wordmark',
      'One size fits most',
    ],
    available: true,
    variant: 'hat',
  },
  {
    slug: 'bone-pocket-tee',
    name: 'Bone Pocket Tee',
    price: 62,
    meta: 'Bone · Garment Dyed',
    stock: 'Drops May 28',
    stockType: 'soon',
    badge: 'soon',
    tag: '03',
    description:
      'Bone-dyed pocket tee with a subtle wordmark. Same heavyweight build as Drop 001 — different character.',
    details: [
      '240gsm heavyweight cotton',
      'Left chest pocket',
      'Garment-dyed bone wash',
      'Relaxed fit — true to size',
    ],
    available: false,
    variant: 'bone',
  },
];

export function getProduct(slug: string): Product | undefined {
  return products.find((p) => p.slug === slug);
}

export interface JournalPost {
  slug: string;
  title: string;
  excerpt: string;
  date: string;
  readTime: string;
  artClass: string;
}

export const journalPosts: JournalPost[] = [
  {
    slug: 'on-garment-dye',
    title: 'On Garment Dye',
    excerpt:
      'Why we wash everything after we sew it — and what that does to a tee over the next ten years.',
    date: 'May 14, 2026',
    readTime: '3 min read',
    artClass: 'journal-art-1',
  },
  {
    slug: 'austin-to-marfa',
    title: 'The Drive From Austin to Marfa',
    excerpt: 'Seven hours, one cooler, no music. The trip that became the first lookbook.',
    date: 'April 28, 2026',
    readTime: '5 min read',
    artClass: 'journal-art-2',
  },
  {
    slug: 'what-in-between-means',
    title: 'What "In-Between" Means',
    excerpt: 'The morning meeting and the canyon road. Why we don\'t pick a lane.',
    date: 'April 10, 2026',
    readTime: '2 min read',
    artClass: 'journal-art-3',
  },
];

export function getJournalPost(slug: string): JournalPost | undefined {
  return journalPosts.find((p) => p.slug === slug);
}
